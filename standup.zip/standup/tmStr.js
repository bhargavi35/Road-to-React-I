import {ms,s,m,h} from "time-convert";

function miliTm(miliSec){
    let store=ms.to(h,m,s)(miliSec);
    let hr = store[0] !== 0 ? `${store[0] > 1 ? `${store[0]} hrs` : `${store[0]} hr`}` : "";
    let min = store[1] !== 0 ? `${store[1] > 1 ? `${store[1]} minutes` : `${store[1]} minute`}` : "";
    let sec = store[2] !== 0 ? `${store[2] > 1 ? `${store[2]} seconds` : `${store[2]} second`}` : "";
    return hr+min+sec;
}

console.log(miliTm(5200));
console.log(miliTm(60000));
console.log(miliTm(180000));
console.log(miliTm(200000));

export default miliTm;