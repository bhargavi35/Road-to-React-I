import miliTm from "./tmStr";

test ("time to String", () =>{
    expect(miliTm(5200)).toBe("5 seconds")
    expect(miliTm(60000)).toBe("1 minute")
    expect(miliTm(180000)).toBe("3 minutes")
    expect(miliTm(200000)).toBe("3 minutes20 seconds")

})